package uz.jl.models.atm;

import uz.jl.enums.Status;

import javax.xml.validation.ValidatorHandler;

/**
 * @author Elmurodov Javohir, Mon 6:14 PM. 11/29/2021
 */
public class Cassette {
    private String id;
    private String currencyValue;
    private String currencyCount;
    private Status status;
    private String atmId;

}
