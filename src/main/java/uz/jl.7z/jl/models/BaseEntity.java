package uz.jl.models;

/**
 * @author Elmurodov Javohir, Mon 5:42 PM. 12/6/2021
 */
public interface BaseEntity {
}
