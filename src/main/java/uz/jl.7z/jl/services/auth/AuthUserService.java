package uz.jl.services.auth;

import uz.jl.models.auth.AuthUser;
import uz.jl.repository.auth.AuthUserRepository;
import uz.jl.services.BaseService;

/**
 * @author Elmurodov Javohir, Mon 6:23 PM. 11/29/2021
 */
public class AuthUserService extends BaseService<AuthUser, AuthUserRepository,UserMapper> {

}
