package uz.jl.response;

/**
 * @author Elmurodov Javohir, Mon 6:29 PM. 12/6/2021
 */

/**
 * @param <RD> -> Response Data
 * @param <S> -> Status
 */
public class ResponseEntity<RD, S> {
}
