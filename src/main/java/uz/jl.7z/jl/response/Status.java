package uz.jl.response;

/**
 * @author Elmurodov Javohir, Mon 6:30 PM. 12/6/2021
 */
public enum Status {
}
