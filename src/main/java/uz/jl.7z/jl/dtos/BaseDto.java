package uz.jl.dtos;

/**
 * @author Elmurodov Javohir, Mon 6:20 PM. 12/6/2021
 */
public interface BaseDto {
}
