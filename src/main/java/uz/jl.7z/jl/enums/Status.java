package uz.jl.enums;

/**
 * @author Elmurodov Javohir, Mon 6:18 PM. 11/29/2021
 */
public enum Status {
    BLOCKED, ACTIVE;
}
