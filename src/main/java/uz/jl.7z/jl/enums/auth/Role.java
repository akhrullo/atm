package uz.jl.enums.auth;

/**
 * @author Elmurodov Javohir, Mon 5:00 PM. 12/6/2021
 */
public enum Role {
    ADMIN,
    EMPLOYEE,
    CLIENT,
    ANONYMOUS;
}
