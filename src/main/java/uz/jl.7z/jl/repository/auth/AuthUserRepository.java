package uz.jl.repository.auth;

import uz.jl.models.auth.AuthUser;
import uz.jl.repository.BaseRepository;

/**
 * @author Elmurodov Javohir, Mon 6:19 PM. 11/29/2021
 */
public class AuthUserRepository extends BaseRepository<AuthUser> {
    @Override
    protected void save(AuthUser user) {

    }
}
