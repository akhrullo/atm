package uz.jl;

import uz.jl.services.auth.AuthUserService;

/**
 * @author Elmurodov Javohir, Mon 6:14 PM. 11/29/2021
 */
public class App {

    public static void main(String[] args) {
        try {
            AuthUserService.login();
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
    }

}
